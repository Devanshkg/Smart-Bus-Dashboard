/* TEMPORARY diagnostic — remove before final deploy. */
exports.handler = async () => {
  const out = { node: process.version };
  try {
    const j = require('jose');
    out.requireJose = 'ok';
    out.requireKeys = Object.keys(j).slice(0, 5);
    out.hasCRJ = typeof j.createRemoteJWKSet;
  } catch (e) {
    out.requireJose = 'FAIL';
    out.requireMsg = String((e && e.code ? e.code + ': ' : '') + (e && e.message || e));
  }
  try {
    const j2 = await import('jose');
    out.importJose = 'ok';
    out.hasCRJ2 = typeof j2.createRemoteJWKSet;
  } catch (e) {
    out.importJose = 'FAIL';
    out.importMsg = String((e && e.code ? e.code + ': ' : '') + (e && e.message || e));
  }
  return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(out) };
};
